let keyword = "join queue"; // default value

// load saved keyword
chrome.storage.sync.get(["keyword"], (result) => {
  if (result.keyword) {
    keyword = result.keyword;
  }
});

setInterval(() => {
  const buttons = document.querySelectorAll("button");

  const target = Array.from(buttons).find(btn =>
    btn.textContent &&
    btn.textContent.toLowerCase().includes(keyword.toLowerCase())
  );

  if (target) {
    console.log("Clicking:", target.textContent.trim());
    target.click();
  }
}, 1000);