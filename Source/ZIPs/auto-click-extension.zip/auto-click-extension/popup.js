document.getElementById("save").addEventListener("click", () => {
  const value = document.getElementById("keyword").value;

  chrome.storage.sync.set({ keyword: value }, () => {
    alert("Saved keyword: " + value);
  });
});