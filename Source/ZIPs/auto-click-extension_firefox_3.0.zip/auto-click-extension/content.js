let keyword = "join queue";

const storage = browser.storage || chrome.storage;

async function loadKeyword() {
  const result = await storage.sync.get("keyword");
  if (result.keyword) keyword = result.keyword;
}

loadKeyword();

setInterval(() => {
  const buttons = document.querySelectorAll("button");

  const target = [...buttons].find(btn =>
    btn.textContent?.toLowerCase().includes(keyword.toLowerCase())
  );

  if (target) target.click();
}, 1000);